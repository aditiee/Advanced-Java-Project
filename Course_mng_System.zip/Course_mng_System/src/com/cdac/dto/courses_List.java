package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="courses")
public class courses_List {
	
	
	@Override
	public String toString() {
		return "courses_List [courseId=" + courseId + ", courseName=" + courseName + ", courseDesc=" + courseDesc
				+ ", courseURL=" + courseURL + ", userId=" + userId + "]";
	}

	@Id
	@GeneratedValue
	@Column(name="courseId")
	private int courseId;
	
	@Column(name="courseName")
	private String courseName;
	
	@Column(name="courseDesc")
	private String courseDesc;
	
	@Column(name="courseURL")
	private String courseURL;

	public String getCourseURL() {
		return courseURL;
	}

	public void setCourseURL(String courseURL) {
		this.courseURL = courseURL;
	}

	@Column(name="userId")
	private int userId;
	
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public courses_List() {
		super();
	}

	

	public courses_List(int courseId) {
		super();
		this.courseId = courseId;
	}

	public int getCourseId() {
		return courseId;
	}

	public void setCourseId(int courseId) {
		this.courseId = courseId;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	public String getCourseDesc() {
		return courseDesc;
	}

	public void setCourseDesc(String courseDesc) {
		this.courseDesc = courseDesc;
	}

	
	
	

}
