package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="account_Details")
public class account_details {
	
	public account_details(int userId) {
		super();
		this.userId = userId;
	}

	@Override
	public String toString() {
		return "account_details [userId=" + userId + ", userName=" + userName + ", email=" + email + ", phoneNo="
				+ phoneNo + ", Address=" + Address + ", education=" + education + ", Country=" + Country + ", State="
				+ State + "]";
	}

	@Id
	@GeneratedValue
	@Column(name="userId")
	private int userId;
	
	@Column(name="userName")
	private String userName;
	
	@Column(name="email")
	private String email;
	
	@Column(name="phoneNo")
	private String phoneNo;
	
	@Column(name="Address")
	private String Address;
	
	@Column(name="education")
	private String education;
	
	@Column(name="Country")
	private String Country;
	
	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPhoneNo() {
		return phoneNo;
	}

	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}

	public String getAddress() {
		return Address;
	}

	public void setAddress(String address) {
		Address = address;
	}

	public String getEducation() {
		return education;
	}

	public void setEducation(String education) {
		this.education = education;
	}

	public String getCountry() {
		return Country;
	}

	public void setCountry(String country) {
		Country = country;
	}

	public String getState() {
		return State;
	}

	public void setState(String state) {
		State = state;
	}

	@Column(name="State")
	private String State;

	public account_details() {
		super();
	}
	
	

}
