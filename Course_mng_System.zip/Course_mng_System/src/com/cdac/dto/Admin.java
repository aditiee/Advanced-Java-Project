package com.cdac.dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="LOGIN")
public class Admin {
	

	@Id
	@GeneratedValue
	@Column(name="userId")
	private int userId;
	
	public int getUserId() {
		return userId;
	}


	public void setUserId(int userId) {
		this.userId = userId;
	}

	@Column(name="userName")
	private String adminName;
	
	
	@Column(name="userPass")
	private String adminPass;
	
	public Admin() {
		super();
	}


	public String getAdminName() {
		return adminName;
	}


	public void setAdminName(String adminName) {
		this.adminName = adminName;
	}


	public String getAdminPass() {
		return adminPass;
	}


	public void setAdminPass(String adminPass) {
		this.adminPass = adminPass;
	}

	
	

}
