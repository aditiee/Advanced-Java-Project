package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;


import com.cdac.dto.courses_List;

@Repository
public class courses_ListDaoImple implements courses_ListDao {

	@Autowired
	private HibernateTemplate hibernateTemplate;
	
	@Override
	public void insertCourse(courses_List course) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(course);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}

			
			
		});
		
	}

	@Override
	public void deleteCourse(int courseId) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				System.out.println("Hiiiiii"+ courseId);
				session.delete(new courses_List(courseId));
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public courses_List selectCourse(int courseId) {
		courses_List course = hibernateTemplate.execute(new HibernateCallback<courses_List>() {

			@Override
			public courses_List doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				courses_List c = (courses_List)session.get(courses_List.class, courseId);
				tr.commit();
				session.flush();
				session.close();
				return c;
			}
			
		});
		return course;
	}

	@Override
	public void updateCourse(courses_List course) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				
//				courses_List cl = (courses_List)session.get(courses_List.class, courses_List.getCourseId());
//				cl.setCourseName(course.getItemName());
//				cl.setCourseDesc(course.getCourseDesc());

				System.out.println("hiiiii");
				System.out.println(course);
				session.update(course);
				
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
			
		});
		
	}

	@Override
	public List<courses_List> selectAll(int userId) {
		List<courses_List> courseList = hibernateTemplate.execute(new HibernateCallback<List<courses_List>>() {

			@Override
			public List<courses_List> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from courses_List where userId = ?");
				q.setInteger(0, userId);
				List<courses_List> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return courseList;

	}
}
