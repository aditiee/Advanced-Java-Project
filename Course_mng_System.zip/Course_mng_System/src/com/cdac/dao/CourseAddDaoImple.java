package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.Course;

@Repository
public class CourseAddDaoImple implements CourseAddDao {

	
		@Autowired
		private HibernateTemplate hibernateTemplate;

		@Override
		public void addCourse(Course course) {
			
			hibernateTemplate.execute(new HibernateCallback<Void>() {

				@Override
				public Void doInHibernate(Session session) throws HibernateException {
					Transaction tr = session.beginTransaction();
					session.save(course);
					tr.commit();
					session.flush();
					session.close();
					return null;
				}
				
			});
		}
		
		
		@Override
		public List<Course> selectAll(int userId) {
			List<Course> courseList = hibernateTemplate.execute(new HibernateCallback<List<Course>>() {

				@Override
				public List<Course> doInHibernate(Session session) throws HibernateException {
					Transaction tr = session.beginTransaction();
					Query q = session.createQuery("from Course where userId = ?");
					q.setInteger(0, userId);
					List<Course> li = q.list();
					System.out.println(li); 
					tr.commit();
					session.flush();
					session.close();
					return li;
				}
				
			});
			return courseList;
		}

	}

	
	
	