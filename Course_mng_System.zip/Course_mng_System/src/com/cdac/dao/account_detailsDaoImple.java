package com.cdac.dao;

import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;
import org.springframework.stereotype.Repository;

import com.cdac.dto.account_details;

@Repository
public class account_detailsDaoImple implements account_detailsDao {
	
	@Autowired
	private HibernateTemplate hibernateTemplate;

	@Override
	public void insertAccDetails(account_details accDetail) {
		hibernateTemplate.execute(new HibernateCallback<Void>() {

			@Override
			public Void doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				session.save(accDetail);
				tr.commit();
				session.flush();
				session.close();
				return null;
			}
		});
			
		
	}
	

	@Override
	public List<account_details> selectAll(int userId) {
		List<account_details> List = hibernateTemplate.execute(new HibernateCallback<List<account_details>>() {

			@Override
			public List<account_details> doInHibernate(Session session) throws HibernateException {
				Transaction tr = session.beginTransaction();
				Query q = session.createQuery("from account_Details where userName = ?");
				q.setInteger(0, userId);
				List<account_details> li = q.list();
				System.out.println(li); 
				tr.commit();
				session.flush();
				session.close();
				return li;
			}
			
		});
		return List;
	}
	
	

	
}
