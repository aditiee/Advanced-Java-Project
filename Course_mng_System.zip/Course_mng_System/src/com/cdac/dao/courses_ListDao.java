package com.cdac.dao;

import java.util.List;

import com.cdac.dto.courses_List;



public interface courses_ListDao {

	void insertCourse(courses_List course);
	void deleteCourse(int courseId);
	courses_List selectCourse(int courseId);
	void updateCourse(courses_List course);
	List<courses_List> selectAll(int userId);
}
