package com.cdac.dao;

import java.util.List;

import com.cdac.dto.account_details;

public interface account_detailsDao {
	
	void insertAccDetails(account_details accDetail);
	List<account_details> selectAll(int userId);
}
