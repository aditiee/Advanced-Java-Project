package com.cdac.dao;

import java.util.List;

import com.cdac.dto.User;

public interface UserDao {
	
	void insertUser(User user);
	boolean checkUser(User user);
	String forgotPassword(String email);
	void uploadImage(String profilePic,int userId);
	void updateUserAccount(User user);
	List<User> selectAllAccountDetails(int userId);
	
	

}
