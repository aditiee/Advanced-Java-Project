package com.cdac.dao;

import java.util.List;

import com.cdac.dto.Course;

public interface CourseAddDao {
	
	void addCourse(Course course);
	List<Course> selectAll(int userId);

}
