package com.cdac.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;


import com.cdac.dto.User;
import com.cdac.dto.account_details;
import com.cdac.service.account_detailsService;

@Controller
public class account_detailsController {
	
	@Autowired
	private account_detailsService accDetailService;
	

	@RequestMapping(value ="/prep_account_settings_form.htm",method = RequestMethod.GET)
	public String prepAccountSettingForm(ModelMap map) {
		map.put("accDetail", new account_details());
		return "account_settings";
	}
	
	@RequestMapping(value ="/account_details.htm",method = RequestMethod.POST)
	public String Add(account_details accDetail,HttpSession session) {
		accDetailService.addAccountDetails(accDetail);
		return "UserHomePage";
	}
	
	
	@RequestMapping(value ="/accountDetail_list.htm",method = RequestMethod.GET)
	public String allAccountDetails(ModelMap map,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		System.out.println("hiiiiiii"+ userId);
		List<account_details> li=accDetailService.selectAll(userId);
		map.put("accDetailList", li);
		return "AccountDetails";
	}
	
	
}
