package com.cdac.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import com.cdac.valid.UserValidator;
import com.cdac.dto.Admin;
import com.cdac.service.AdminService;


@Controller
public class AdminController {

	@Autowired
	private AdminService adminService;
	
	@Autowired
	private UserValidator userValidator;
	
	@RequestMapping(value = "/admin_log_form.htm",method = RequestMethod.GET)
	public String prepLogForm(ModelMap map) {
		map.put("admin", new Admin());
		return "AdminLogin";
	}
	
	@RequestMapping(value = "/adminLogin.htm",method = RequestMethod.POST)
	public String login(Admin admin,BindingResult result,ModelMap map,HttpSession session) {
		
		
		boolean b = adminService.findAdmin(admin);
		if(b) {
			session.setAttribute("admin", admin); 
			return "AdminHomePage";
		}else {
			map.put("admin", new Admin());
			return "AdminLogin";
		}
	
	}
	@RequestMapping(value = "/adminlogout.htm",method = RequestMethod.GET)
	public String preplogout(Admin admin,ModelMap map,HttpSession session) {
	
			session.setAttribute("admin", admin); 
			map.put("admin", new Admin());
			return "AdminLogin";
		}
}
