package com.cdac.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cdac.dto.Admin;
import com.cdac.dto.courses_List;
import com.cdac.service.courses_ListService;

@Controller
public class courses_ListController {
	
	@Autowired
	private courses_ListService courses_ListService;
	
	@RequestMapping(value = "/prep_course_add_form.htm",method = RequestMethod.GET)
	public String prepCourseAddForm(ModelMap map) {
		map.put("course", new courses_List());
		return "Courseadd_form";
	}
	
	@RequestMapping(value = "/course_add.htm",method = RequestMethod.POST)
	public String courseAdd(courses_List course,HttpSession session) {
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		course.setUserId(userId);
		courses_ListService.addCourse(course);
		return "AdminHomePage";
	}
	
	@RequestMapping(value = "/course_list.htm",method = RequestMethod.GET)
	public String allCourses(ModelMap map,HttpSession session) {
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		List<courses_List> li = courses_ListService.selectAll(userId);
		map.put("courseList", li);
		return "course_list";
	}
	
	@RequestMapping(value = "/course_delete.htm",method = RequestMethod.GET)
	public String deleteCourse(@RequestParam int courseId,ModelMap map,HttpSession session) {
		
		courses_ListService.removeCourse(courseId);
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		List<courses_List> li = courses_ListService.selectAll(userId);
		map.put("courseList", li);
		return "course_list";
	}
	
	@RequestMapping(value = "/course_update_form.htm",method = RequestMethod.GET)
	public String updateCourseForm(@RequestParam int courseId,ModelMap map,HttpSession session) {
		
		courses_List cl = courses_ListService.findCourse(courseId);
		map.put("course", cl);
		session.setAttribute("courseId", courseId);
		
		return "course_update_form";
	}
	
	@RequestMapping(value = "/course_update.htm",method = RequestMethod.POST)
	public String updateCourse(courses_List course,ModelMap map,HttpSession session) {
		
		int userId = ((Admin)session.getAttribute("admin")).getUserId();
		course.setUserId(userId);
		int courseId = (int) session.getAttribute("courseId");
		course.setCourseId(courseId);
		courses_ListService.modifyCourse(course);
		List<courses_List> li = courses_ListService.selectAll(userId);
		map.put("courseList", li);
		return "course_list";
	}
	
}
