package com.cdac.controller;

import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.cdac.dto.Course;
import com.cdac.dto.User;
import com.cdac.service.CourseAddService;

@Controller
public class CourseAddController {
	
	@Autowired
	private CourseAddService courseAddService;
	
	
	@RequestMapping(value = "/prep_enroll_course.htm",method = RequestMethod.GET)
	public String prepCourseAdd(ModelMap map) {
		map.put("course", new Course());
		return "Enroll";
	}
	
	@RequestMapping(value = "/enroll_course.htm",method = RequestMethod.POST)
	public String registerCourse(Course course,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		course.setUserId(userId); 
		courseAddService.insertCourse(course);
		return "JavaCourse";
	}
	
	@RequestMapping(value = "/registeredCourses.htm",method = RequestMethod.GET)
	public String allCourses(ModelMap map,HttpSession session) {
		int userId = ((User)session.getAttribute("user")).getUserId();
		List<Course> li =courseAddService.selectAll(userId);
		map.put("courseList", li);
		return "MyCourses";
	}


	
	
}
