package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.account_detailsDao;
import com.cdac.dto.account_details;

@Service
public class account_detailsServiceImple implements account_detailsService{


	@Autowired
	private account_detailsDao accDetailDao;
	
	@Override
	public void addAccountDetails(account_details accDetail) {
		accDetailDao.insertAccDetails(accDetail);
		
	}

	@Override
	public List<account_details> selectAll(int userId) {
		
		return accDetailDao.selectAll(userId);
	}

}
