package com.cdac.service;

import java.util.List;

import com.cdac.dto.User;

public interface UserService {
	
	void addUser(User user);
	boolean findUser(User user);
	String forgotPassword(String email);
	void uploadImage(String profilePic,int userId);
	void modifyUserAccount(User user);
	List<User> selectAllAccountDetails(int userId);

}
