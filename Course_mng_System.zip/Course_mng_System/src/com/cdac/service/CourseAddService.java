package com.cdac.service;

import java.util.List;

import com.cdac.dto.Course;

public interface CourseAddService {
	
	void insertCourse(Course course);
	List<Course> selectAll(int userId);


}
