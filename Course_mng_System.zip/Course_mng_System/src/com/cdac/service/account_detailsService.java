package com.cdac.service;

import java.util.List;

import com.cdac.dto.account_details;

public interface account_detailsService {
	void addAccountDetails(account_details accDetail);
	List<account_details> selectAll(int userId);
}
