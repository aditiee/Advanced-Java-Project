package com.cdac.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cdac.dao.courses_ListDao;
import com.cdac.dto.courses_List;

@Service
public class courses_ListServiceImple implements courses_ListService{

	@Autowired
	private courses_ListDao courses_ListDao;
	
	@Override
	public void addCourse(courses_List course) {
		courses_ListDao.insertCourse(course);
		
	}

	@Override
	public void removeCourse(int courseId) {
		courses_ListDao.deleteCourse(courseId);
		
	}

	@Override
	public courses_List findCourse(int courseId) {
		
		return courses_ListDao.selectCourse(courseId);
	}

	@Override
	public void modifyCourse(courses_List course) {
		courses_ListDao.updateCourse(course);
		
	}

	@Override
	public List<courses_List> selectAll(int courseId) {
		
		return courses_ListDao.selectAll(courseId);
	}

}
