package com.cdac.service;

import java.util.List;

import com.cdac.dto.courses_List;

public interface courses_ListService {
	void addCourse(courses_List course);
	void removeCourse(int courseId);
	courses_List findCourse(int courseId);
	void modifyCourse(courses_List course);
	List<courses_List> selectAll(int courseId);
}
